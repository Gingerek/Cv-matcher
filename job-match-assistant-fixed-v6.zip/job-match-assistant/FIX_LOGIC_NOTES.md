# Fix: CV-driven job matching logic

Implemented safeguards:

1. CV professional profile is now the primary search source.
2. Hobby/interests section is ignored for detecting the target job category.
3. Standalone agency/source terms such as `uitzendbureau`, `uitzend`, `cao`, `seu`, `temporary workers` are blocked as search queries.
4. Manual keywords are optional only and cannot override the CV profile.
5. Google Jobs/API query, company name and source are no longer used to classify the real job category.
6. Production/logistics/warehouse/care titles receive hard mismatch caps when the CV profile is recruitment/MSP, IT, content, or another white-collar profile.
7. A production role posted by an employment agency is now classified as production, not recruitment.
8. Debug output now shows the detected real job category and why the score was capped.

Expected result for the reported case:
`Productiemedewerker 3-ploegen in Helmond` should no longer receive a high score for a recruitment/MSP CV. It should be capped low because the title is production/logistics, even if the posting was found via an agency-related source.
