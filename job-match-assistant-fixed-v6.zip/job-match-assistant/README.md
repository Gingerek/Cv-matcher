# Job Match Assistant – Helmond

Aplikacja Streamlit do automatycznego wyszukiwania aktualnych ofert pracy w okolicy Helmond i oceniania dopasowania do CV w skali 1–10.

## Co robi aplikacja

- wczytuje Twoje CV z pliku PDF, DOCX albo TXT,
- najpierw analizuje CV i wykrywa profil zawodowy,
- wykrywa główną kategorię pracy, mocne tytuły, twarde umiejętności, miękkie umiejętności, języki, lokalizację, poziom seniority i branże,
- tworzy zapytania do API dynamicznie z CV,
- traktuje ręczne słowa kluczowe tylko jako opcjonalny dodatek,
- pokazuje wykryty profil CV, finalne zapytania API i odrzucone kategorie,
- automatycznie szuka aktualnych ofert pracy,
- filtruje okolice Helmond,
- liczy dystans, jeżeli oferta ma współrzędne albo rozpoznawalną lokalizację,
- pokazuje dopasowanie 1–10,
- nakłada mocne kary za niedopasowane kategorie, np. content creator vs recruiter/MSP albo IT consultant vs magazyn/kierowca/opieka/recruitment,
- pokazuje plusy, minusy i debug scoringu dla każdej oferty,
- pokazuje finalne zapytania wysłane do Adzuna/SerpApi oraz liczbę ofert na zapytanie,
- pokazuje salary range, jeżeli źródło je zwróci,
- pozwala eksportować wyniki do CSV.

## Ważne

Aplikacja nie wymaga ręcznego dodawania ofert, ale do realnego pobierania aktualnych ofert potrzebujesz kluczy API.

Najlepsza konfiguracja:
1. Adzuna API: APP ID + APP KEY
2. opcjonalnie SerpApi: API KEY dla Google Jobs

Klucze możesz wpisać w panelu bocznym aplikacji albo zapisać w pliku `.env`.

## Instalacja na Windows

1. Rozpakuj ZIP.
2. Wejdź do folderu projektu.
3. Kliknij dwa razy `run_app.bat`.

## Ręczne uruchomienie

```bat
py -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
streamlit run app\main.py
```

## Plik .env

Możesz utworzyć plik `.env` w głównym folderze:

```env
ADZUNA_APP_ID=twoj_app_id
ADZUNA_APP_KEY=twoj_app_key
SERPAPI_KEY=twoj_serpapi_key
```
