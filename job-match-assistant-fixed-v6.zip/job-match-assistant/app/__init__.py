"""Job Match Assistant package."""
